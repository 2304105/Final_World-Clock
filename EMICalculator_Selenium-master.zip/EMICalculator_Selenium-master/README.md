## Problem Statement
Find the interest amount for current year for:
- Buying a  car of 15 Lac
- Interest rate of 9.5% 
- Tenure should be 1 year.

Display the interest amount & principal amount of first month.

Website used: emicalculator.net
