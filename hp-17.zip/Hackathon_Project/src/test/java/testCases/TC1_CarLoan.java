package testCases;

public class TC1_CarLoan {
	
}
