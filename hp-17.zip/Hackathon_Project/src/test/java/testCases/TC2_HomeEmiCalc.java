package testCases;

public class TC2_HomeEmiCalc {

}
