package testCases;

public class TC3_LoanCalc {
	
}
